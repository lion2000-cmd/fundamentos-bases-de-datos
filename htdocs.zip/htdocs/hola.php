<?php
echo 'Hola mundo';
