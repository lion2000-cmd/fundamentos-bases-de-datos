<html>
<head>
<title>Formulario</title>
<link rel="stylesheet" type="text/css" href="estilo1.css">
</head>
<body>
<form method ="GET" action ="leerFormulario.php" target="_blank">
<label>nombre</label>
<input type="text" name="nombre"></input>
<label>edad</label>
<input type="number" name="edad"></input>
<button type="submit"> enviar</button>
</form>
</body>
