<?php
$nombre=$_GET["nombre"];
$edad=$_GET["edad"];
echo "Hola $nombre tienes $edad años";
