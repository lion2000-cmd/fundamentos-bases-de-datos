<?php
$server="127.0.0.1";
$usuario="root";
$contraseña="";
$bd="empresa";
$conexion = mysqli_connect($server,$usuario,$contraseña) or die ("error al conectar el servidor");
?>
